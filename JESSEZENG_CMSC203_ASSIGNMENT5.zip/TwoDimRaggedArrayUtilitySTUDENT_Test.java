

import static org.junit.Assert.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TwoDimRaggedArrayUtilitySTUDENT_Test {
	//STUDENT fill in dataSetSTUDENT with values, it must be a ragged array
	private double[][] dataSetSTUDENT = null;
	private double[][] data1 = {{7.2,2.5,9.3},{5.9},{8.1,1.7,3.3},{11.6,6.9,7.3,2.7}};
	private double[][] data2 = {{-2.5,-5.3,6.1},{-4.4,8.2},{2.3,-7.5},{-4.2,7.3,-5.9,2.6}};
	
	private File inputFile,outputFile;

	@Before
	public void setUp() throws Exception {
		outputFile = new File("TestOut.txt");
	}

	@After
	public void tearDown() throws Exception {
		 data1 = data2 = null;
		inputFile = outputFile = null;
	}

	/**
	 * Student Test getTotal method
	 * Return the total of all the elements in the two dimensional array
	 */
	@Test
	public void testGetTotal() {
		
		assertEquals(66.5,TwoDimRaggedArrayUtility.getTotal(data1),.001);
		assertEquals(-3.3,TwoDimRaggedArrayUtility.getTotal(data2),.001);
	}
	

	/**
	 * Student Test getAverage method
	 * Return the average of all the elements in the two dimensional array
	 */
	@Test
	public void testGetAverage() {
		
		assertEquals(6.045,TwoDimRaggedArrayUtility.getAverage(data1),.001);
		assertEquals(-.3,TwoDimRaggedArrayUtility.getAverage(data2),.001);
		//fail("Not yet implemented");
	}

	/**
	 * Student Test getRowTotal method
	 * Return the total of all the elements of the row.
	 * Row 0 refers to the first row in the two dimensional array
	 */
	@Test
	public void testGetRowTotal() {
		
		assertEquals(5.9,TwoDimRaggedArrayUtility.getRowTotal(data1,1),.001);
		assertEquals(3.8,TwoDimRaggedArrayUtility.getRowTotal(data2,1),.001);
		
	
	}


	/**
	 * Student Test getColumnTotal method
	 * Return the total of all the elements in the column. If a row in the two dimensional array
	 * doesn't have this column index, it is not an error, it doesn't participate in this method.
	 * Column 0 refers to the first column in the two dimensional array
	 */
	@Test
	public void testGetColumnTotal() {
	
		assertEquals(11.1,TwoDimRaggedArrayUtility.getColumnTotal(data1,1),.001);
		assertEquals(-8.8,TwoDimRaggedArrayUtility.getColumnTotal(data2,0),.001);
		
		
	}


	/**
	 * Student Test getHighestInArray method
	 * Return the largest of all the elements in the two dimensional array.
	 */
	@Test
	public void testGetHighestInArray() {
		
	
		assertEquals(11.6,TwoDimRaggedArrayUtility.getHighestInArray(data1),.001);
		assertEquals(8.2,TwoDimRaggedArrayUtility.getHighestInArray(data2),.001);
		assertEquals(2.7,TwoDimRaggedArrayUtility.getColumnTotal(data2,1),.001);
		
	}
	

	/**
	 * Test the writeToFile method
	 * write the array to the outputFile File
	 * then read it back to make sure formatted correctly to read
	 * 
	 */
	@Test
	public void testWriteToFile() {
		/**
		 * Test the writeToFile method
		 * write the array to the outputFile File
		 * then read it back to make sure formatted correctly to read
		 * 
		 */
		double[][] array=null;
		try {
			TwoDimRaggedArrayUtility.writeToFile(data2, outputFile);
		} catch (Exception e) {
			fail("This should not have caused an Exception");
		}
		array = TwoDimRaggedArrayUtility.readFile(outputFile);
		assertEquals(-5.3, array[0][1],.001);
		assertEquals(6.1, array[0][2],.001);
		assertEquals(-4.4, array[1][0],.001);
		assertEquals(8.2, array[1][1],.001);
	
	}

}
