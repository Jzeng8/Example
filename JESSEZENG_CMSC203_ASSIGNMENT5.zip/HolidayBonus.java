class HolidayBonus extends java.lang.Object{
    public static double[] calculateHolidayBonus(double[][] data, double high, double low, double other) {
       double[] bonusamount = new double[data.length];
       int row,col = 0;
       for(row = 0; row < data.length; row++) {
            for(col = 0; col < data[row].length; col++) {
                if(data[row][col] < 0){
                    continue;
                }else if(TwoDimRaggedArrayUtility.getHighestInColumn(data, col) == data[row][col]    ) {
                    bonusamount[row] += high;
                }
                else if(TwoDimRaggedArrayUtility.getLowestInColumn(data, col) == data[row][col] ){
                	bonusamount[row] += low;
                }
                else if(TwoDimRaggedArrayUtility.getLowestInColumn(data, col) != data[row][col] ) {
                	bonusamount[row] += other;
                }
            }
  
        }
        return bonusamount;
    }

   public static double calculateTotalHolidayBonus(double[][] data, double high, double low, double other) {
        int a,b=0;
        for(a = 0; a < calculateHolidayBonus(data, high, low, other).length; a++) {
            b += calculateHolidayBonus(data, high, low, other)[a];
        }
        return b;
    }

}