
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Scanner;
public class TwoDimRaggedArrayUtility {
	
	static double[][] readFile(java.io.File file){
		
		int a = 0,b=0;
		String line,name = null;
		double[][] array=new double[6][];
		
		try{
			BufferedReader variable =new BufferedReader(new FileReader(file));      
			while((line=variable.readLine())!=name){
				String[] temp=line.split(" ");
				int size=temp.length;
				array[a]=new double[size];
				for(b=0;b<size;b++){
					array[a][b]= Double.parseDouble(temp[b]);
				}
				a++;
				if(b>0){
				b++;	
				}
			}
			variable.close();
		}
		catch(Exception ep){	
		}
		return array;
	}

	static void writeToFile(double[][] data, java.io.File outputFile){
		String line;
		int a,b;
		try{
			Scanner write=new Scanner(outputFile);

			for (a=0;a<data.length;a++){
				line= ""+data[a][0];
				for(b=0;b<data[a].length;b++){
					line+= " "+ data[a][b];
				}
				write.nextLine();
			}
			write.close();
		}
		catch(Exception ep){
			ep.printStackTrace();
		}

}

	static double getTotal(double[][] data)
	{
		int a,b;
		double totalamount=0;

		for(a=0;a<data.length;a++){
			for(b=0;b<data[a].length;b++){
				totalamount += data[a][b];
			}
		}
		return totalamount;
	}

	static double getAverage(double[][] data)
	{
		int a,b;
		double number=0,totalvalue=0,num=1;
		for(a=0;a<data.length;a++){
			for(b=0;b<data[a].length;b++){
				totalvalue += data[a][b];
				number += num;
			}
		}
		return new Double(totalvalue/number);
	}

	static double getRowTotal(double[][] data,int row)
	{
		int a;
		double rowtotal=0;
		for(a=0;a<data[row].length;a++) {
				rowtotal += data[row][a];
		}
		return rowtotal;
	}

	static double getColumnTotal(double[][] data,int col)
	{
		double coltotal=0;
		int a;
		for(a=0;a<data.length;a++){
			try {
				coltotal += data[a][col];
			}catch (Exception e){
				continue;
			}
		}
		return coltotal;
	}

	static double getHighestInRow(double[][] data,int row)
	{
		double highest=data[row][0];
		for(int a=0;a<data[row].length;a++)
		{
			if(data[row][a]>highest) {
				highest= data[row][a];
			}
		}
		return highest;
	}
	static int getHighestInRowIndex(double[][] data, int row) {
		int high = 0;
		int a;
		for (a = 0; a < data[row].length; ++a) {
			if (data[row][a] > data[row][high]) {
				high = a;
			}
		}
		return high;
	}

	static double getLowestInRow(double[][] data,int row)
	{
		double lowest =data[row][getLowestInRowIndex(data, row)];
		return lowest;
	}
	static int getLowestInRowIndex(double[][] data, int row)
	{
		int a,low = 0;
		for (a= 0; a<data[row].length; a++) {
			if (data[row][a] < data[row][low]) {
				low = a;
			}
		}
		return low;

	}

	static double getHighestInColumn(double[][] data,int col)
	{
		double highest = data[getHighestInColumnIndex(data, col)][col];
		return highest;
	}
	static int getHighestInColumnIndex(double[][] data, int col){
		int a,highestcol = 1;
		double num = Integer.MIN_VALUE;
		for(a= 0; a<data.length;a++){
			try {
				if(data[a][col] > num) {
					num = data[a][col];
					highestcol = a;
				}
			}
			catch(Exception e){
				continue;
			}
		}
		return highestcol;
	}
	static double getLowestInColumn(double[][] data,int col)
	{
		double lowestcol = data[getLowestInColumnIndex(data, col)][col];
		return lowestcol;
	}
	static int getLowestInColumnIndex(double data[][], int col){

		double lowest = Integer.MAX_VALUE;
		int a,num = 1;
		for(a = 0;a<data.length;a++) {
			try {
				if(data[a][col] < lowest) {
					lowest = data[a][col];
					num = a;
				}
			}
			catch(Exception e){
				continue;
			}
		}
		return num;
	}

	static double getHighestInArray(double[][] data){
		int a,b;
		for(a=0;a<data.length;a++){
			for(b=0;b<data[a].length;b++){
				if(data[a][b]>data[0][0]) {
					data[0][0]= data[a][b];
				}
				if(data[a][b]!=data[0][0]) {
					continue;
				}
			}
		}
		return data[0][0];
	}

	static double getLowestInArray(double[][] data){
		int a,b=0;
		for(a=0;a<data.length;a++){
			for(b=0;b<data[a].length;b++){
				if(data[a][b]<data[0][0]) {
					data[0][0]= data[a][b];
				}
				if(data[a][b]!=data[0][0]) {
					continue;
				}	
			}
		}
		return data[0][0];
	}

}
