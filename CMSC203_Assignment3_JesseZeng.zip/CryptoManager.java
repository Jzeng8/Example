public class CryptoManager {
   private static final char lOWER_BOUND = 32;
   private static final char UPPER_BOUND = 95;
   private static final int DISTANCE = 95-32+1;

  
public static boolean stringInBounds (String plainText) {
   
	boolean bounds = true;
       
   for (int a = 0; a < plainText.length(); a++){
           if (!(plainText.charAt(a) >= lOWER_BOUND && plainText.charAt(a) <= UPPER_BOUND))
               bounds = false;
       }
           return bounds;
           
}

  
public static String encryptCaesar(String plainText, int key) {


	
	key = newkey(key);

	String alpha = "";
	
    for (int x = 0; x < plainText.length(); x++){
     alpha += Character.toString((char) ((int) plainText.charAt(x) + key));
    }

   

    return alpha;
    
  }

  
public static String encryptBellaso(String plainText, String bellasoStr){
	
   String text = "";
   
   int amount = bellasoStr.length();
      
   for (int a = 0; a < plainText.length(); a++){
	   char thisChar = plainText.charAt(a);
           int encryptword = ((int)thisChar+(int)bellasoStr.charAt(a%amount));
               
           while (encryptword > (int)UPPER_BOUND){
               encryptword -= DISTANCE;
               }
          
            text += (char)encryptword;
            
       }
     
       return text;
}

  
public static String decryptCaesar(String encryptedText, int key) {
   

    key = newkey(key);

  
    String worded = "";



    for (int i = 0; i < encryptedText.length(); i++){
      worded += Character.toString((char) ((int) encryptedText.charAt(i) - key));
    }



    return worded;
  }

  public static int newkey(int key){
	  
    while (key > 95){
     
    	key -= (95- 32);
    }

    return key;
 
  }

  
public static String decryptBellaso(String encryptedText, String bellasoStr){ 
	
	

   String decrypts = "";
   int bellasoStrLength = bellasoStr.length();
      
   for (int a = 0; a < encryptedText.length(); a ++){
          
	   char TheChar = encryptedText.charAt(a);
           
           int decryptedvalue = ((int)TheChar-(int)bellasoStr.charAt(a%bellasoStrLength));
          
           while (decryptedvalue < (int)lOWER_BOUND){
              
        	   decryptedvalue += DISTANCE;
        	   
           }
         
           decrypts += (char)decryptedvalue;
       }
      
       return decrypts;
       
   
}

}