
public enum SIZE {
SMALL,MEDIUM,LARGE;
}
