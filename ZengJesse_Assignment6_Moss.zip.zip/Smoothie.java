public class Smoothie extends Beverage {
	 private boolean protein;
	private int fruit;


    public Smoothie(String name, SIZE size,int ExtraFruit, boolean ExtraProtein) {
       
    	super(name,TYPE.SMOOTHIE,size);
        this.protein = ExtraProtein;
        this.fruit = ExtraFruit;
   
    }
    public String toString(){
       
    	return name + size + calcPrice();
   
    }

    @Override
    public double calcPrice() {
       
    	double BasePrice = 2.0;

        if(this.fruit > 0) {
            BasePrice += .50 * this.fruit;
        }
        if(this.protein == true) {
        	BasePrice +=1.50;
        }
        if(this.size.equals(SIZE.MEDIUM)){
        	BasePrice += 1.00;
        }
        if(this.size.equals(SIZE.LARGE)) {
        	BasePrice += 2.00;
        }

        return BasePrice; 
    }

    public boolean equals(String name, TYPE type, SIZE size, int fruit, boolean protein) {
        if(this.name.equals(name)) {
            if(this.type.equals(type)) {
                if(this.size.equals(size)) {
                    if(this.fruit > 0) {
                        if(this.protein == true) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }
   
    public CharSequence getBevName() {
        // TODO Auto-generated method stub
        return this.name;
    }
    public Object getSize() {
        // TODO Auto-generated method stub
        return this.size;
    }
    public int getNumOfFruits() {
        // TODO Auto-generated method stub
        return this.fruit;
    }
    public boolean getAddProtien() {
        // TODO Auto-generated method stub
        return this.protein;
    }
    @Override
    protected TYPE getType() {
        // TODO Auto-generated method stub
        return this.type;
    }
    }