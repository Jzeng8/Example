public abstract class Beverage {

    protected String name;
    protected TYPE type;
    protected SIZE size; 

    static final double BasePrice = 2.0; 
    static final int SizePrice = 1; 

Beverage(String name,TYPE type, SIZE size) {
    this.name =  name; 
    this.type = type;
    this.size = size; 
}

public abstract double calcPrice();




public String toString() {

    return name + size;
}

public boolean equals(Beverage bev) {

    if(this.name.equals(bev.name)) {
        if(this.type.equals(bev.type)) {
            if(this.size.equals(bev.size)) {

                return true; 

            }
        }

    }
    return false;
}
public double getBasePrice() {
    // TODO Auto-generated method stub
    return BasePrice;
}

public CharSequence getBevName() {
    // TODO Auto-generated method stub
    return this.name;
}

public Object getSize() {
    // TODO Auto-generated method stub
    return this.size;
}

protected Object getType() {
    // TODO Auto-generated method stub
    return this.type;
}



}