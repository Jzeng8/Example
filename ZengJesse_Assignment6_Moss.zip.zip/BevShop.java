import java.util.ArrayList;

public class BevShop implements BevShopInterface{

	ArrayList<Order> list = new ArrayList<Order>();	
	int orderedAlcohol;


	@Override
	public boolean validTime(int time) {
		int timezone = 8;
		int timezone2 = 23;
		if(time >= timezone && time <= timezone2) {
			return true;
		}
		return false;
	}

	@Override
	public boolean eligibleForMore() {

		Order thisOrder = getCurrentOrder();
		this.orderedAlcohol = thisOrder.findNumOfBeveType(TYPE.ALCOHOL);

		if(MAX_ORDER_FOR_ALCOHOL > this.orderedAlcohol){
			return true;
		}
		return false;
	}

	@Override
	public boolean validAge(int age) {

		if(MIN_AGE_FOR_ALCOHOL < age){
			return true;
		}
		return false;
	}

	@Override
	public void startNewOrder(int time, DAY day, String cName, int cAge) {

		Customer newCustomer = new Customer(cName, cAge);
		Order newOrder = new Order(time, day, newCustomer);
		this.list.add(newOrder);

	}


	@Override
	public void processCoffeeOrder(String bName, SIZE bsize, boolean extraShot, boolean extraSyrup) {

		Order newCoffee = getCurrentOrder();
		newCoffee.addNewBeverage(bName,  bsize,  extraShot,  extraSyrup);

	}


	@Override
	public void processAlcoholOrder(String bName, SIZE bsize) {
		Order newAlcohol = getCurrentOrder();
		newAlcohol.addNewBeverage(bName, bsize);

	}


	@Override
	public void processSmoothieOrder(String bName, SIZE bsize, int numFruits, boolean addProtien) {
		Order newSmoothie = getCurrentOrder();
		newSmoothie.addNewBeverage(bName, bsize, numFruits, addProtien);

	}


	@Override
	public int findOrder(int orderNo) {

		int orderIndex = 0;
		int i;
		for(i = 0; i < this.list.size(); i++)
		{
			if(list.get(i).getOrderNo() == orderNo)
			{
				orderIndex = i;
			}
		}
		return orderIndex;

	}


	@Override
	public double totalOrderPrice(int orderNo)
	{
		return getOrderAtIndex(findOrder(orderNo)).calcOrderTotal();
	}

	@Override
	public double totalMonthlySale() {
		double total = 0.0;

		for (int i = 0; i < list.size(); i++)
		{
			total += list.get(i).calcOrderTotal();
		}
		return total;
	}

	@Override
	public void sortOrders() {
		Order lowestOrder = new Order();
		int lowestIndex = 0;
		int i,j;
		
		for( i = 0; i < list.size(); i++)
		{
			lowestOrder = list.get(i);
			lowestIndex = i;

			for(j = i + 1; j < list.size(); j++)
			{
				if(list.get(j).getOrderNo() < list.get(i).getOrderNo())
				{
					lowestOrder = list.get(j);
					lowestIndex = j;
				}
			}

			Order temp = new Order();

			temp = list.get(i);
			list.set(i, lowestOrder);
			list.set(lowestIndex, temp);

		}

	}


	@Override
	public Order getOrderAtIndex(int index) {

		return this.list.get(index);
	}


	public Order getCurrentOrder() {
		return list.get(list.size() - 1);
	}


	public Object totalNumOfMonthlyOrders() {

		return list.size();
	}


	public boolean isMaxFruit(int i) {

		if(MAX_FRUIT < i)
		{
			return true;
		}
		return false;
	}


	public int getNumOfAlcoholDrink() {

		int alcoholDrinks = 0;

		alcoholDrinks = getCurrentOrder().findNumOfBeveType(TYPE.ALCOHOL);	

		return alcoholDrinks;
	}


	public String toString()
	{
		String orderList = "";
		int i;

		for(i = 0; i < list.size(); i++)
		{
			orderList += list.get(i);
		}

		orderList += totalMonthlySale();

		return orderList;
	}


	public int getMaxOrderForAlcohol() {		
		return MAX_ORDER_FOR_ALCOHOL ;
	}


	public int getMinAgeForAlcohol()
	{
		return MIN_AGE_FOR_ALCOHOL;
	}

}
