
public enum TYPE {
	COFFEE,SMOOTHIE,ALCOHOL;
}
