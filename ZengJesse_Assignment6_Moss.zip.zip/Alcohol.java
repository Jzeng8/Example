public class Alcohol extends Beverage{

    private boolean Weekend;

    public Alcohol(String name, SIZE size, boolean AWeekend) {
        super(name,TYPE.ALCOHOL,size);

        this.Weekend = AWeekend;

    }
    public String toString(){
        return name + size + calcPrice();
    }

    @Override
    public double calcPrice() {
        double price = 2.0;


        if(this.Weekend == true) {
            price += 0.60;
        }
        if(this.size.equals(SIZE.MEDIUM)){
            price += 1.00;
        }
        if(this.size.equals(SIZE.LARGE)) {
            price += 2.00;
        }

        return price; 
    }

    public boolean equals(String name, TYPE type, SIZE size, int fruit, boolean protein) {
        if(this.name.equals(name)) {
            if(this.type.equals(type)) {
                if(this.size.equals(size)) {
                        if(this.Weekend == true) {
                            return true;
                        }
                    }
                }
            }

        return false;
    }
    public CharSequence getBevName() {
        // TODO Auto-generated method stub
        return this.name;
    }

    public Object getSize() {
        // TODO Auto-generated method stub
        return this.size;
    }
    @Override
    protected TYPE getType() {
        // TODO Auto-generated method stub
        return this.type;
    }


}