import java.util.ArrayList;
import java.util.Random;

class Order implements OrderInterface{
	
	public Order()
	{

	}
	
	private DAY day;
	private Customer customer;
	private int orderNumber;
	private int orderTime;
	private ArrayList<Beverage> beverages = new ArrayList<Beverage>();
	
	public void Order1()
	{

	}
	
	public Order(int orderTime, DAY day, Customer customer)
	{
		this.orderNumber = randomNum();
		this.orderTime = orderTime;
		this.day = day;
		this.customer = customer;
	}

	public int randomNum()
	{
		int randomNum;
		int num = 90000;
		int num2 = 10000;
		
		Random ranNum = new Random();

		randomNum = ranNum.nextInt(num - num2 +1) + num2;

		return randomNum;
	}


	public void addNewBeverage(String name, SIZE size, boolean extraShot, boolean extraSyrup)
	{
		Coffee typeofdrink = new Coffee(name, size, extraShot, extraSyrup);

		this.beverages.add(typeofdrink);
	}


	public void addNewBeverage(String bName, SIZE size, int numFruits, boolean addProtien)
	{
		Smoothie typeofdrink = new Smoothie(bName, size, numFruits, addProtien);

		this.beverages.add(typeofdrink);
	}

	public void addNewBeverage( String name, SIZE size)
	{
		Alcohol typeofdrink = new Alcohol(name, size, this.isWeekend());

		this.beverages.add(typeofdrink);
	}


	public String toString()
	{

		String bevList = "";
		int a;
		
		for(a = 0; a < beverages.size(); a++){
			bevList = bevList + beverages.get(a).toString();
		}
		String text = this.orderNumber + " " + this.orderTime + " " + this.day + " " + this.customer.getName() + " " + this.customer.getAge() + " " + bevList + " " + calcOrderTotal();

		return text;
	}


	public int compareTo(Order order)
	{
		int numorder = 0;

		if(order.getOrderNo() == this.orderNumber)
		{
			numorder = 0;
		}
		else if(order.getOrderNo() < this.orderNumber) 
		{
			numorder = -1;
		}
		else if(order.getOrderNo() > this.orderNumber)
		{
			numorder = 1;
		}

		return numorder;

	}
	
	public DAY getOrderDay()
	{
		return this.day;
	}


	public Customer getCustomer()
	{
		return new Customer(this.customer.getName(), this.customer.getAge());
	}


	@Override
	public boolean isWeekend() {

		if(this.day == DAY.SUNDAY || this.day == DAY.SATURDAY)
		{
			return true;
		}
		return false;
	}

	@Override
	public Beverage getBeverage(int beveragenum) {

		return beverages.get(beveragenum);
	}


	@Override
	public double calcOrderTotal() {

		double total = 0.0;
		int a;
		
		for(a = 0; a < this.beverages.size(); a++){
			total += this.beverages.get(a).calcPrice();
		}
		return total;
	}



	@Override
	public int findNumOfBeveType(TYPE type) {
		int num = 0;
		int a;
		
		for(a = 0; a < this.beverages.size(); a++){
			if(this.beverages.get(a).getType() == type)
			{
				num++;
			}
		}
		return num;
	}

	public void setOrderNum(int _orderNum)
	{
		this.orderNumber = _orderNum;
	}


	public void setOrderTime(int _orderTime)
	{
		this.orderTime = _orderTime;
	}


	public void setOrderDay(DAY day)
	{
		this.day = day;
	}


	public void setCustomer(Customer _customer)
	{
		this.customer = _customer;
	}


	public int getOrderNo()
	{
		return this.orderNumber;
	}


	public int getOrderTime()
	{
		return this.orderTime;
	}

	public int getTotalItems()
	{	
		return this.beverages.size();
	}

	

}
