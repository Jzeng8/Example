public class Coffee extends Beverage{ 

	private boolean Syrup;
	private boolean Shot; 



	public Coffee(String name, SIZE size, boolean ExtraShot, boolean ExtraSyrup) 
	{
		super(name,TYPE.COFFEE,size); 
		this.Syrup = ExtraSyrup; 
		this.Shot= ExtraShot;

	}

	public String toString(){
		return name + size + calcPrice(); 
	}

	@Override
	public double calcPrice() {

		double BasePrice = 2.0; 

		if(this.Shot== true) {
			BasePrice += .50;
		}
		if(this.Syrup == true) {
			BasePrice +=.50;
		}
		if(this.size.equals(SIZE.MEDIUM)){
			BasePrice += 1.00;
		}
		if(this.size.equals(SIZE.LARGE)) {
			BasePrice += 2.00;
		}

		return BasePrice; 
	}

	public boolean equals(String name, TYPE type, SIZE size, boolean Shot, boolean Syrup) {

		if(this.name.equals(name)) {
			if(this.type.equals(type)) {
				if(this.size.equals(size)) {
					if(this.Shot == Shot) {
						if(this.Syrup == Syrup) {

							return true;
						}
					}

				}
			}
		}
		return false;
	}


	public CharSequence getBevName() {
		// TODO Auto-generated method stub
		return this.name;
	}

	public Object getSize() {
		// TODO Auto-generated method stub
		return this.size;
	}

	public boolean getExtraShot() {
		// TODO Auto-generated method stub
		return this.Shot;
	}

	public boolean getExtraSyrup() {
		// TODO Auto-generated method stub
		return this.Syrup;
	}
	@Override
	protected TYPE getType() {
		// TODO Auto-generated method stub
		return this.type;
	}


}